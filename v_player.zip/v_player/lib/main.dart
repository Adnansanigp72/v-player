import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';
import 'player_page.dart';

const _seed = Color(0xFF7C4DFF);
const _themeKey = 'theme_dark';
final themeNotifier = ValueNotifier<ThemeMode>(ThemeMode.dark);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final isDark = prefs.getBool(_themeKey) ?? true;
  themeNotifier.value = isDark ? ThemeMode.dark : ThemeMode.light;
  runApp(const VPlayerApp());
}

Future<void> toggleTheme() async {
  final isDark = themeNotifier.value == ThemeMode.dark;
  final next = !isDark;
  themeNotifier.value = next ? ThemeMode.dark : ThemeMode.light;
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool(_themeKey, next);
}

ThemeData _buildTheme(Brightness b) {
  final isDark = b == Brightness.dark;
  return ThemeData(
    useMaterial3: true,
    brightness: b,
    colorScheme: ColorScheme.fromSeed(seedColor: _seed, brightness: b),
    scaffoldBackgroundColor:
        isDark ? const Color(0xFF0E0E14) : const Color(0xFFF5F5FA),
  );
}

class VPlayerApp extends StatelessWidget {
  const VPlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (context, mode, _) => MaterialApp(
        title: 'V Player',
        debugShowCheckedModeBanner: false,
        themeMode: mode,
        theme: _buildTheme(Brightness.light),
        darkTheme: _buildTheme(Brightness.dark),
        home: const HomePage(),
      ),
    );
  }
}

enum _LoadState { loading, denied, ready }

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  _LoadState _state = _LoadState.loading;

  // ফোন থেকে স্ক্যান করা ভিডিও
  List<VideoItem> _phoneVideos = [];
  final Map<String, AssetEntity> _entities = {};
  final Map<String, Future<Uint8List?>> _thumbs = {};

  // URL দিয়ে যোগ করা ভিডিও
  final List<VideoItem> _urlVideos = [];

  Timer? _debounce;
  bool _watching = false;

  List<VideoItem> get _all => [..._urlVideos, ..._phoneVideos];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _scan();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _debounce?.cancel();
    if (_watching) {
      PhotoManager.removeChangeCallback(_onMediaChanged);
      PhotoManager.stopChangeNotify();
    }
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // অ্যাপে ফিরলে একবার রিফ্রেশ, যাতে কোনো পরিবর্তন বাদ না যায়
    if (state == AppLifecycleState.resumed && _state == _LoadState.ready) {
      _scan(silent: true);
    }
  }

  // ---------- Live watch ----------

  void _startWatching() {
    if (_watching) return;
    _watching = true;
    PhotoManager.addChangeCallback(_onMediaChanged);
    PhotoManager.startChangeNotify();
  }

  void _onMediaChanged(MethodCall call) {
    // একসাথে অনেক ফাইল যোগ হলে বারবার স্ক্যান না করে একবারই করা হবে
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 800), () {
      if (mounted && _state == _LoadState.ready) _scan(silent: true);
    });
  }

  // ---------- Scan ----------

  Future<void> _scan({bool silent = false}) async {
    if (!silent) setState(() => _state = _LoadState.loading);

    final perm = await PhotoManager.requestPermissionExtend();
    if (!perm.hasAccess) {
      if (mounted) setState(() => _state = _LoadState.denied);
      return;
    }

    final paths = await PhotoManager.getAssetPathList(
      type: RequestType.video,
      onlyAll: true,
    );
    final assets = paths.isEmpty
        ? <AssetEntity>[]
        : await paths.first.getAssetListRange(start: 0, end: 2000);

    _entities
      ..clear()
      ..addEntries(assets.map((a) => MapEntry(a.id, a)));

    if (!mounted) return;
    final before = _phoneVideos.length;
    setState(() {
      _phoneVideos = [
        for (final a in assets)
          VideoItem(
            title: a.title ?? 'ভিডিও',
            source: a.id,
            isAsset: true,
            durationSeconds: a.duration,
          ),
      ];
      _state = _LoadState.ready;
    });

    _startWatching();

    final added = _phoneVideos.length - before;
    if (silent && added > 0 && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$added টি নতুন ভিডিও যোগ হয়েছে')),
      );
    }
  }

  Future<Uint8List?> _thumbFor(String id) {
    return _thumbs.putIfAbsent(id, () async {
      final entity = _entities[id];
      if (entity == null) return null;
      return entity.thumbnailDataWithSize(const ThumbnailSize(240, 135));
    });
  }

  // ---------- Actions ----------

  Future<void> _addUrl() async {
    final controller = TextEditingController();
    final url = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('URL থেকে চালাও'),
        content: TextField(
          controller: controller,
          autofocus: true,
          keyboardType: TextInputType.url,
          decoration: const InputDecoration(
            hintText: 'https://example.com/video.mp4',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('বাতিল'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('চালাও'),
          ),
        ],
      ),
    );

    if (url == null || url.isEmpty) return;
    final uri = Uri.tryParse(url);
    if (uri == null || !uri.hasScheme) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('সঠিক URL দাও')),
        );
      }
      return;
    }

    final title = uri.pathSegments.isNotEmpty ? uri.pathSegments.last : url;
    setState(() {
      _urlVideos.add(VideoItem(title: title, source: url, isNetwork: true));
    });
    _open(0);
  }

  void _open(int index) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PlayerPage(
          playlist: _all,
          startIndex: index,
        ),
      ),
    );
  }

  // ---------- UI ----------

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'V Player',
          style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            tooltip: 'আবার স্ক্যান',
            icon: Icon(Icons.refresh, color: scheme.onSurface),
            onPressed: _scan,
          ),
          IconButton(
            tooltip: 'থিম বদলাও',
            icon: Icon(
              isDark ? Icons.light_mode_outlined : Icons.dark_mode_outlined,
              color: scheme.onSurface,
            ),
            onPressed: toggleTheme,
          ),
        ],
      ),
      body: switch (_state) {
        _LoadState.loading => const Center(child: CircularProgressIndicator()),
        _LoadState.denied => _buildMessage(scheme,
            icon: Icons.lock_outline,
            text: 'ফোনের ভিডিও দেখতে অনুমতি দাও',
            button: 'অনুমতি দাও',
            onTap: _scan),
        _LoadState.ready => _all.isEmpty
            ? _buildMessage(scheme,
                icon: Icons.video_library_outlined,
                text: 'ফোনে কোনো ভিডিও পাওয়া যায়নি',
                button: 'আবার স্ক্যান',
                onTap: _scan)
            : _buildList(scheme),
      },
    );
  }

  Widget _buildMessage(
    ColorScheme scheme, {
    required IconData icon,
    required String text,
    required String button,
    required VoidCallback onTap,
  }) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 64, color: scheme.primary),
            const SizedBox(height: 20),
            Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: onTap,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Text(button),
                ),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _addUrl,
                icon: const Icon(Icons.link),
                label: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text('URL দিয়ে চালাও'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildList(ColorScheme scheme) {
    final all = _all;
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
      itemCount: all.length + 1,
      itemBuilder: (context, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(8, 0, 8, 12),
            child: Row(
              children: [
                Expanded(
                  child: FilledButton.tonalIcon(
                    onPressed: () => _open(0),
                    icon: const Icon(Icons.play_arrow),
                    label: Text('সব চালাও (${all.length})'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _addUrl,
                    icon: const Icon(Icons.link),
                    label: const Text('URL'),
                  ),
                ),
              ],
            ),
          );
        }

        final index = i - 1;
        final item = all[index];
        return Card(
          margin: const EdgeInsets.symmetric(vertical: 6),
          color: scheme.surfaceContainerHighest,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: ListTile(
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            leading: _thumbnail(item),
            title: Text(
              item.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            subtitle: Text(
              item.isNetwork
                  ? 'ইন্টারনেট'
                  : _fmtDuration(item.durationSeconds),
              style: TextStyle(color: scheme.onSurface.withValues(alpha: 0.5)),
            ),
            trailing: const Icon(Icons.play_circle_outline),
            onTap: () => _open(index),
          ),
        );
      },
    );
  }

  String _fmtDuration(int seconds) {
    if (seconds <= 0) return 'লোকাল ফাইল';
    final h = seconds ~/ 3600;
    final m = (seconds % 3600) ~/ 60;
    final s = seconds % 60;
    String two(int n) => n.toString().padLeft(2, '0');
    return h > 0 ? '$h:${two(m)}:${two(s)}' : '${two(m)}:${two(s)}';
  }

  Widget _thumbnail(VideoItem item) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        width: 96,
        height: 56,
        child: item.isAsset
            ? FutureBuilder<Uint8List?>(
                future: _thumbFor(item.source),
                builder: (context, snap) => snap.data != null
                    ? Image.memory(snap.data!, fit: BoxFit.cover)
                    : _placeholder(item),
              )
            : _placeholder(item),
      ),
    );
  }

  Widget _placeholder(VideoItem item) {
    return ColoredBox(
      color: item.isNetwork ? const Color(0xFF00897B) : _seed,
      child: Icon(
        item.isNetwork ? Icons.cloud_outlined : Icons.movie_outlined,
        color: Colors.white,
      ),
    );
  }
}
