import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'package:file_picker/file_picker.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:screen_brightness/screen_brightness.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';
import 'subtitles.dart';

const _accent = Color(0xFF7C4DFF);
const _speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];

String _fmt(Duration d) {
  String two(int n) => n.toString().padLeft(2, '0');
  final h = d.inHours;
  final m = d.inMinutes % 60;
  final s = d.inSeconds % 60;
  return h > 0 ? '$h:${two(m)}:${two(s)}' : '${two(m)}:${two(s)}';
}

class PlayerPage extends StatefulWidget {
  final List<VideoItem> playlist;
  final int startIndex;

  const PlayerPage({
    super.key,
    required this.playlist,
    this.startIndex = 0,
  });

  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  late int _index;
  VideoPlayerController? _controller;
  String? _error;

  bool _showControls = true;
  bool _isFullscreen = false;
  bool _loop = false;
  double _speed = 1.0;
  double _volume = 1.0;

  List<SubtitleCue> _cues = [];
  bool _subsOn = true;

  BoxFit _fit = BoxFit.contain;
  Timer? _sleepTimer;
  bool _stopAfterThis = false;
  Timer? _saveTimer;
  bool _holdingSpeed = false;
  double _brightness = 0.5;

  Timer? _hideTimer;
  Timer? _gestureTimer;
  String? _gestureLabel;

  @override
  void initState() {
    super.initState();
    _index = widget.startIndex;
    WakelockPlus.enable();
    _loadBrightness();
    _loadVideo(_index);
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    _gestureTimer?.cancel();
    _saveTimer?.cancel();
    _sleepTimer?.cancel();
    _savePosition();
    ScreenBrightness().resetApplicationScreenBrightness().catchError((_) {});
    _controller?.removeListener(_onTick);
    _controller?.dispose();
    WakelockPlus.disable();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    super.dispose();
  }

  // ---------- Loading ----------

  Future<void> _loadVideo(int index) async {
    _saveTimer?.cancel();
    await _savePosition();
    final old = _controller;
    old?.removeListener(_onTick);
    setState(() {
      _controller = null;
      _error = null;
      _index = index;
      _cues = [];
    });
    await old?.dispose();

    final item = widget.playlist[index];
    final path = item.isNetwork ? null : await _resolvePath(item);
    if (!item.isNetwork && path == null) {
      if (mounted) setState(() => _error = 'ভিডিও ফাইলটি খুঁজে পাওয়া যায়নি');
      return;
    }
    final c = item.isNetwork
        ? VideoPlayerController.networkUrl(Uri.parse(item.source))
        : VideoPlayerController.file(File(path!));

    try {
      await c.initialize();
      await c.setLooping(_loop);
      await c.setPlaybackSpeed(_speed);
      await c.setVolume(_volume);
      final saved = await _loadSavedPosition(widget.playlist[index]);
      if (saved != null) await c.seekTo(saved);
      c.addListener(_onTick);
      await c.play();
      if (!mounted) {
        c.dispose();
        return;
      }
      setState(() => _controller = c);
      _scheduleHide();
      _saveTimer = Timer.periodic(
        const Duration(seconds: 5),
        (_) => _savePosition(),
      );
      if (saved != null) _flashGesture('⏯ আগের জায়গা থেকে চালু');
    } catch (e) {
      await c.dispose();
      if (mounted) setState(() => _error = 'ভিডিও চালানো যায়নি\n$e');
    }
  }

  void _onTick() {
    final c = _controller;
    if (c == null || !mounted) return;
    final v = c.value;
    final ended = v.isInitialized &&
        !v.isPlaying &&
        v.duration > Duration.zero &&
        v.position >= v.duration;

    if (ended && _stopAfterThis) {
      _stopAfterThis = false;
      setState(() {});
      return;
    }

    // শেষ হলে পরের ভিডিও অটো-প্লে (লুপ অফ থাকলে)
    if (ended && !_loop && _index < widget.playlist.length - 1) {
      _playNext();
      return;
    }
    setState(() {});
  }

  void _playNext() {
    if (_index < widget.playlist.length - 1) _loadVideo(_index + 1);
  }

  void _playPrev() {
    if (_index > 0) _loadVideo(_index - 1);
  }

  // ---------- Brightness ----------

  Future<void> _loadBrightness() async {
    try {
      _brightness = await ScreenBrightness().application;
    } catch (_) {
      // কিছু ডিভাইসে পড়া না গেলে ডিফল্ট ০.৫ থাকবে
    }
  }

  void _changeBrightness(double dy, double height) {
    _brightness = (_brightness - dy / height * 1.5).clamp(0.05, 1.0);
    ScreenBrightness()
        .setApplicationScreenBrightness(_brightness)
        .catchError((_) {});
    _flashGesture('☀️ ${(_brightness * 100).round()}%');
  }

  // ---------- Source ----------

  Future<String?> _resolvePath(VideoItem item) async {
    if (!item.isAsset) return item.source;
    final entity = await AssetEntity.fromId(item.source);
    final file = await entity?.file;
    return file?.path;
  }

  // ---------- Resume ----------

  String _resumeKey(VideoItem item) => 'resume:${item.source}';

  Future<Duration?> _loadSavedPosition(VideoItem item) async {
    final prefs = await SharedPreferences.getInstance();
    final ms = prefs.getInt(_resumeKey(item));
    return ms == null ? null : Duration(milliseconds: ms);
  }

  Future<void> _savePosition() async {
    final c = _controller;
    if (c == null || !c.value.isInitialized) return;
    final key = _resumeKey(widget.playlist[_index]);
    final pos = c.value.position.inMilliseconds;
    final dur = c.value.duration.inMilliseconds;
    final prefs = await SharedPreferences.getInstance();
    if (pos > 5000 && pos < dur - 5000) {
      await prefs.setInt(key, pos);
    } else {
      await prefs.remove(key); // শেষ হলে বা শুরুতে থাকলে মনে রাখার দরকার নেই
    }
  }

  // ---------- Sleep timer ----------

  void _setSleep({int? minutes, bool endOfVideo = false}) {
    _sleepTimer?.cancel();
    _sleepTimer = null;
    _stopAfterThis = endOfVideo;

    String? label;
    if (minutes != null) {
      _sleepTimer = Timer(Duration(minutes: minutes), () {
        _controller?.pause();
        _sleepTimer = null;
      });
      label = '$minutes মিনিট';
    } else if (endOfVideo) {
      label = 'ভিডিও শেষ হলে';
    }
    setState(() {});
    _flashGesture(label == null
        ? '😴 স্লিপ টাইমার বন্ধ'
        : '😴 $label পর থামবে');
  }

  void _showSleepMenu() {
    void pick(VoidCallback action) {
      Navigator.pop(context);
      action();
    }

    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1B1B26),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            const Text(
              'স্লিপ টাইমার',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            for (final m in [15, 30, 45, 60])
              ListTile(
                leading: const Icon(Icons.bedtime_outlined),
                title: Text('$m মিনিট পর থামবে'),
                onTap: () => pick(() => _setSleep(minutes: m)),
              ),
            ListTile(
              leading: const Icon(Icons.stop_circle_outlined),
              title: const Text('ভিডিও শেষ হলে থামবে'),
              onTap: () => pick(() => _setSleep(endOfVideo: true)),
            ),
            ListTile(
              leading: const Icon(Icons.timer_off_outlined),
              title: const Text('টাইমার বন্ধ'),
              onTap: () => pick(() => _setSleep()),
            ),
          ],
        ),
      ),
    );
  }

  // ---------- Fit mode ----------

  void _cycleFit() {
    setState(() {
      _fit = _fit == BoxFit.contain
          ? BoxFit.cover
          : _fit == BoxFit.cover
              ? BoxFit.fill
              : BoxFit.contain;
    });
    _flashGesture(switch (_fit) {
      BoxFit.cover => '🖼️ পূর্ণ স্ক্রিন',
      BoxFit.fill => '🖼️ টেনে ভরাও',
      _ => '🖼️ মূল অনুপাত',
    });
  }

  // ---------- Hold for 2x ----------

  void _holdSpeedStart() {
    _holdingSpeed = true;
    _controller?.setPlaybackSpeed(2.0);
    _flashGesture('⚡ 2x (ধরে রাখা)');
  }

  void _holdSpeedEnd() {
    if (!_holdingSpeed) return;
    _holdingSpeed = false;
    _controller?.setPlaybackSpeed(_speed);
  }

  // ---------- Subtitles ----------

  Future<void> _pickSubtitle() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['srt', 'vtt'],
    );
    final file = result?.files.single;
    if (file?.path == null) return;

    try {
      final cues = await SubtitleParser.loadFile(file!.path!);
      if (!mounted) return;
      setState(() {
        _cues = cues;
        _subsOn = true;
      });
      _flashGesture(cues.isEmpty
          ? '💬 সাবটাইটেল খালি'
          : '💬 ${cues.length}টি লাইন লোড হয়েছে');
    } catch (_) {
      if (mounted) _flashGesture('💬 সাবটাইটেল পড়া যায়নি');
    }
  }

  void _toggleSubs() {
    if (_cues.isEmpty) {
      _pickSubtitle();
      return;
    }
    setState(() => _subsOn = !_subsOn);
    _flashGesture(_subsOn ? '💬 সাবটাইটেল চালু' : '💬 সাবটাইটেল বন্ধ');
  }

  String? _currentSubtitle(Duration pos) {
    for (final cue in _cues) {
      if (pos >= cue.start && pos < cue.end) return cue.text;
    }
    return null;
  }

  Widget _buildSubtitle() {
    final pos = _controller?.value.position ?? Duration.zero;
    final text = _subsOn ? _currentSubtitle(pos) : null;

    return AnimatedPositioned(
      duration: const Duration(milliseconds: 200),
      left: 16,
      right: 16,
      bottom: _showControls ? 160 : 40,
      child: IgnorePointer(
        child: text == null
            ? const SizedBox.shrink()
            : Center(
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    text,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      height: 1.3,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
      ),
    );
  }

  // ---------- Controls ----------

  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && (_controller?.value.isPlaying ?? false)) {
        setState(() => _showControls = false);
      }
    });
  }

  void _toggleControls() {
    setState(() => _showControls = !_showControls);
    if (_showControls) _scheduleHide();
  }

  void _togglePlay() {
    final c = _controller;
    if (c == null) return;
    c.value.isPlaying ? c.pause() : c.play();
    setState(() => _showControls = true);
    _scheduleHide();
  }

  void _seekRelative(int seconds) {
    final c = _controller;
    if (c == null) return;
    var target = c.value.position + Duration(seconds: seconds);
    if (target < Duration.zero) target = Duration.zero;
    if (target > c.value.duration) target = c.value.duration;
    c.seekTo(target);
    _flashGesture(seconds > 0 ? '⏩ +${seconds}s' : '⏪ ${seconds}s');
  }

  void _changeVolume(double dy, double height) {
    final c = _controller;
    if (c == null) return;
    _volume = (_volume - dy / height * 1.5).clamp(0.0, 1.0);
    c.setVolume(_volume);
    _flashGesture('🔊 ${(_volume * 100).round()}%');
  }

  void _cycleSpeed() {
    final i = _speeds.indexOf(_speed);
    _speed = _speeds[(i + 1) % _speeds.length];
    _controller?.setPlaybackSpeed(_speed);
    _flashGesture('⚡ ${_speed}x');
  }

  void _toggleLoop() {
    setState(() => _loop = !_loop);
    _controller?.setLooping(_loop);
    _flashGesture(_loop ? '🔁 লুপ চালু' : '🔁 লুপ বন্ধ');
  }

  void _flashGesture(String text) {
    _gestureTimer?.cancel();
    setState(() => _gestureLabel = text);
    _gestureTimer = Timer(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => _gestureLabel = null);
    });
  }

  Future<void> _toggleFullscreen() async {
    _isFullscreen = !_isFullscreen;
    if (_isFullscreen) {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      await SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
    } else {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      await SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    }
    setState(() {});
  }

  void _showPlaylist() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1B1B26),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => SafeArea(
        child: ListView.builder(
          shrinkWrap: true,
          padding: const EdgeInsets.symmetric(vertical: 12),
          itemCount: widget.playlist.length,
          itemBuilder: (_, i) {
            final active = i == _index;
            return ListTile(
              leading: Icon(
                active ? Icons.play_circle_fill : Icons.movie_outlined,
                color: active ? _accent : Colors.white70,
              ),
              title: Text(
                widget.playlist[i].title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: active ? FontWeight.bold : FontWeight.normal,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                if (!active) _loadVideo(i);
              },
            );
          },
        ),
      ),
    );
  }

  // ---------- UI ----------

  @override
  Widget build(BuildContext context) {
    final c = _controller;
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _toggleControls,
        onLongPressStart: (_) => _holdSpeedStart(),
        onLongPressEnd: (_) => _holdSpeedEnd(),
        onDoubleTapDown: (d) {
          final w = MediaQuery.of(context).size.width;
          d.localPosition.dx < w / 2 ? _seekRelative(-10) : _seekRelative(10);
        },
        onVerticalDragUpdate: (d) {
          final size = MediaQuery.of(context).size;
          if (d.localPosition.dx > size.width / 2) {
            _changeVolume(d.delta.dy, size.height);
          } else {
            _changeBrightness(d.delta.dy, size.height);
          }
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            Center(child: _buildVideo(c)),
            _buildSubtitle(),
            if (_gestureLabel != null)
              Center(child: _GestureBadge(text: _gestureLabel!)),
            AnimatedOpacity(
              opacity: _showControls ? 1 : 0,
              duration: const Duration(milliseconds: 250),
              child: IgnorePointer(
                ignoring: !_showControls,
                child: _buildControls(c),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideo(VideoPlayerController? c) {
    if (_error != null) {
      return Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          _error!,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white70),
        ),
      );
    }
    if (c == null || !c.value.isInitialized) {
      return const CircularProgressIndicator(color: _accent);
    }
    if (_fit == BoxFit.contain) {
      return AspectRatio(
        aspectRatio: c.value.aspectRatio,
        child: VideoPlayer(c),
      );
    }
    return SizedBox.expand(
      child: FittedBox(
        fit: _fit,
        child: SizedBox(
          width: c.value.size.width,
          height: c.value.size.height,
          child: VideoPlayer(c),
        ),
      ),
    );
  }

  Widget _buildControls(VideoPlayerController? c) {
    final item = widget.playlist[_index];
    final pos = c?.value.position ?? Duration.zero;
    final dur = c?.value.duration ?? Duration.zero;
    final playing = c?.value.isPlaying ?? false;
    final maxMs = dur.inMilliseconds > 0 ? dur.inMilliseconds.toDouble() : 1.0;

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.black87, Colors.transparent, Colors.transparent, Colors.black87],
          stops: [0, 0.25, 0.7, 1],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            // Top bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Text(
                      item.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'স্ক্রিন ফিট',
                    icon: const Icon(Icons.aspect_ratio, color: Colors.white),
                    onPressed: _cycleFit,
                  ),
                  IconButton(
                    tooltip: 'স্লিপ টাইমার',
                    icon: Icon(
                      Icons.bedtime_outlined,
                      color: _sleepTimer != null || _stopAfterThis
                          ? _accent
                          : Colors.white,
                    ),
                    onPressed: _showSleepMenu,
                  ),
                  IconButton(
                    icon: const Icon(Icons.playlist_play, color: Colors.white),
                    onPressed: _showPlaylist,
                  ),
                ],
              ),
            ),

            const Spacer(),

            // Center controls
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _circleBtn(Icons.skip_previous_rounded,
                    _index > 0 ? _playPrev : null, size: 40),
                const SizedBox(width: 20),
                _circleBtn(Icons.replay_10_rounded, () => _seekRelative(-10)),
                const SizedBox(width: 16),
                _circleBtn(
                  playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  _togglePlay,
                  size: 64,
                  filled: true,
                ),
                const SizedBox(width: 16),
                _circleBtn(Icons.forward_10_rounded, () => _seekRelative(10)),
                const SizedBox(width: 20),
                _circleBtn(
                  Icons.skip_next_rounded,
                  _index < widget.playlist.length - 1 ? _playNext : null,
                  size: 40,
                ),
              ],
            ),

            const Spacer(),

            // Bottom controls
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
              child: Column(
                children: [
                  SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      trackHeight: 4,
                      thumbShape:
                          const RoundSliderThumbShape(enabledThumbRadius: 7),
                      overlayShape: SliderComponentShape.noOverlay,
                      activeTrackColor: _accent,
                      inactiveTrackColor: Colors.white24,
                      thumbColor: Colors.white,
                    ),
                    child: Slider(
                      value: pos.inMilliseconds.toDouble().clamp(0.0, maxMs),
                      max: maxMs,
                      onChanged: c == null
                          ? null
                          : (v) => c.seekTo(Duration(milliseconds: v.round())),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('${_fmt(pos)} / ${_fmt(dur)}',
                            style: const TextStyle(color: Colors.white70)),
                        Text(
                          '${item.isNetwork ? 'ইন্টারনেট' : 'লোকাল'} • ${_index + 1}/${widget.playlist.length}',
                          style: const TextStyle(color: Colors.white54, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _pillBtn('${_speed}x', _cycleSpeed),
                      Row(
                        children: [
                          IconButton(
                            tooltip: 'সাবটাইটেল ফাইল',
                            icon: const Icon(Icons.subtitles_outlined,
                                color: Colors.white),
                            onPressed: _pickSubtitle,
                          ),
                          IconButton(
                            tooltip: 'সাবটাইটেল চালু/বন্ধ',
                            icon: Icon(
                              Icons.closed_caption,
                              color: _subsOn && _cues.isNotEmpty
                                  ? _accent
                                  : Colors.white70,
                            ),
                            onPressed: _toggleSubs,
                          ),
                          IconButton(
                            icon: Icon(
                              Icons.repeat,
                              color: _loop ? _accent : Colors.white70,
                            ),
                            onPressed: _toggleLoop,
                          ),
                          IconButton(
                            icon: Icon(
                              _isFullscreen
                                  ? Icons.fullscreen_exit
                                  : Icons.fullscreen,
                              color: Colors.white,
                            ),
                            onPressed: _toggleFullscreen,
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _circleBtn(IconData icon, VoidCallback? onTap,
      {double size = 48, bool filled = false}) {
    return Material(
      color: filled ? _accent : Colors.white12,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: size,
          height: size,
          child: Icon(
            icon,
            size: size * 0.6,
            color: onTap == null ? Colors.white24 : Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _pillBtn(String label, VoidCallback onTap) {
    return Material(
      color: Colors.white12,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}

class _GestureBadge extends StatelessWidget {
  final String text;
  const _GestureBadge({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.black54,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
