class VideoItem {
  final String title;
  final String source; // লোকাল: ফাইল path / ফোনের ভিডিও: asset id / URL
  final bool isNetwork;
  final bool isAsset; // ফোনের MediaStore থেকে আসা ভিডিও
  final int durationSeconds;

  const VideoItem({
    required this.title,
    required this.source,
    this.isNetwork = false,
    this.isAsset = false,
    this.durationSeconds = 0,
  });
}
