import 'dart:convert';
import 'dart:io';

class SubtitleCue {
  final Duration start;
  final Duration end;
  final String text;

  const SubtitleCue({
    required this.start,
    required this.end,
    required this.text,
  });
}

/// SRT ও WebVTT ফরম্যাট পড়ে।
class SubtitleParser {
  static final _timeLine = RegExp(
    r'((?:\d+:)?\d{1,2}:\d{2}[,.]\d{3})\s*-->\s*((?:\d+:)?\d{1,2}:\d{2}[,.]\d{3})',
  );
  static final _tags = RegExp(r'<[^>]+>|\{\\an\d\}');

  static Future<List<SubtitleCue>> loadFile(String path) async {
    final bytes = await File(path).readAsBytes();
    final text = utf8.decode(bytes, allowMalformed: true);
    return parse(text);
  }

  static List<SubtitleCue> parse(String raw) {
    final text = raw
        .replaceFirst('\uFEFF', '')
        .replaceAll('\r\n', '\n')
        .replaceAll('\r', '\n');

    final cues = <SubtitleCue>[];
    for (final block in text.split(RegExp(r'\n\s*\n'))) {
      final lines = block.trim().split('\n');
      final timeIdx = lines.indexWhere((l) => l.contains('-->'));
      if (timeIdx == -1) continue;

      final match = _timeLine.firstMatch(lines[timeIdx]);
      if (match == null) continue;

      final body = lines
          .sublist(timeIdx + 1)
          .join('\n')
          .replaceAll(_tags, '')
          .trim();
      if (body.isEmpty) continue;

      cues.add(SubtitleCue(
        start: _parseTime(match.group(1)!),
        end: _parseTime(match.group(2)!),
        text: body,
      ));
    }

    cues.sort((a, b) => a.start.compareTo(b.start));
    return cues;
  }

  static Duration _parseTime(String s) {
    final parts = s.replaceAll(',', '.').split(':');
    int hours = 0;
    String minutes;
    String secondsPart;

    if (parts.length == 3) {
      hours = int.parse(parts[0]);
      minutes = parts[1];
      secondsPart = parts[2];
    } else {
      minutes = parts[0];
      secondsPart = parts[1];
    }

    final secParts = secondsPart.split('.');
    return Duration(
      hours: hours,
      minutes: int.parse(minutes),
      seconds: int.parse(secParts[0]),
      milliseconds: int.parse(secParts[1]),
    );
  }
}
