# V Player — Play Store Release Guide

## ধাপ ১: Upload Keystore তৈরি (একবারই)

তোমার কম্পিউটারে Java ইনস্টল থাকলে এই কমান্ড চালাও:

```bash
keytool -genkey -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

পাসওয়ার্ড ও alias মনে রাখো। **keystore ফাইল ও পাসওয়ার্ড হারিয়ে গেলে আপডেট দেওয়া যাবে না**, তাই ব্যাকআপ রাখো।

Base64 বানাও (GitHub Secret-এর জন্য):

```bash
# Linux/macOS
base64 -w 0 upload-keystore.jks > keystore.txt

# Windows PowerShell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("upload-keystore.jks")) | Out-File keystore.txt
```

## ধাপ ২: GitHub Secrets সেট করো

Repository → **Settings → Secrets and variables → Actions → New repository secret**

| Secret নাম | মান |
|---|---|
| `KEYSTORE_BASE64` | `keystore.txt` এর ভিতরের লেখা |
| `STORE_PASSWORD` | keystore পাসওয়ার্ড |
| `KEY_PASSWORD` | key পাসওয়ার্ড (সাধারণত একই) |
| `KEY_ALIAS` | `upload` |
| `APP_ID` | যেমন `com.tumarnam.vplayer` (একবার ঠিক করলে আর বদলানো যাবে না) |

> ⚠️ `keystore.txt` ও `upload-keystore.jks` কখনো GitHub-এ commit করবে না। `.gitignore` এ এগুলো আগে থেকেই আছে।

## ধাপ ৩: বিল্ড চালাও

- কোড GitHub-এ push করো।
- **Actions** ট্যাব → **Build AAB for Play Store** → **Run workflow**।
- শেষে **Artifacts** থেকে `v-player-aab` ডাউনলোড করো। এতে `app-release.aab` ফাইল পাবে।

পরের আপডেটে `pubspec.yaml` এর `version` বদলাও (যেমন `1.0.1+2`)। Build number স্বয়ংক্রিয়ভাবে বাড়বে।

## ধাপ ৪: Play Console-এ আপলোড

1. [Google Play Console](https://play.google.com/console) এ ডেভেলপার অ্যাকাউন্ট খুলো (একবার $25)।
2. **Create app** → নাম: `V Player`।
3. **Production / Testing → Create new release** → `app-release.aab` আপলোড করো।
4. Play App Signing চালু থাকবে। Google নিজেও signing key ম্যানেজ করবে।

## ধাপ ৫: Store-এর জন্য যা লাগবে

- **App icon:** 512×512 PNG
- **Feature graphic:** 1024×500 PNG
- **Screenshots:** কমপক্ষে ২টি (ফোন)
- **Short description** (৮০ অক্ষর) ও **Full description**
- **Privacy Policy URL:** ইন্টারনেট ও স্টোরেজ পারমিশনের জন্য লাগবে। একটি সাধারণ পেজ GitHub Pages বা Notion-এ বানাতে পারো। লেখা উচিত: "অ্যাপ ব্যবহারকারীর কোনো ব্যক্তিগত তথ্য সংগ্রহ বা শেয়ার করে না, ভিডিও শুধু ডিভাইসে বা URL থেকে চালায়।"
- **Data safety form:** "কোনো ডেটা সংগ্রহ করা হয় না" নির্বাচন করো।
- **Content rating:** প্রশ্নাবলী পূরণ করো।
- **Target audience:** ১৩+ বা সাধারণ নির্বাচন করো।

## ধাপ ৬: App Icon ও নাম পরিবর্তন (ঐচ্ছিক)

Android-এ আইকন বদলাতে `flutter_launcher_icons` প্যাকেজ ব্যবহার করতে পারো। অথবা Android Studio-তে **Image Asset** দিয়ে সহজে বানাতে পারো।

## নোট

- URL থেকে ভিডিও চালানোর ক্ষেত্রে ব্যবহারকারী নিজের লিংক দেয়, তাই কপিরাইট সংক্রান্ত দায়িত্ব ব্যবহারকারীর। Store description-এ এটা উল্লেখ করা ভালো।
- Google Play নতুন অ্যাপের জন্য সাধারণত সর্বশেষ Android API level (targetSdk) চায়। Flutter সংস্করণ আপডেট রাখলে এটা স্বয়ংক্রিয়ভাবে মিলে যায়।
