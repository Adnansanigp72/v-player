"""
Play Store-এর জন্য Android প্রজেক্ট ঠিক করে:
- INTERNET পারমিশন ও HTTP ভিডিও অনুমতি
- অ্যাপের নাম "V Player"
- applicationId (APP_ID env থেকে)
- release signing (KEYSTORE_PATH, STORE_PASSWORD, KEY_PASSWORD, KEY_ALIAS env থেকে)
"""
import os
import pathlib
import re

ROOT = pathlib.Path("android/app")
MANIFEST = ROOT / "src/main/AndroidManifest.xml"
APP_ID = os.environ.get("APP_ID", "").strip()

# ---------- Manifest ----------
manifest = MANIFEST.read_text(encoding="utf-8")

if "android.permission.INTERNET" not in manifest:
    manifest = manifest.replace(
        "<application",
        '<uses-permission android:name="android.permission.INTERNET"/>\n    <application',
        1,
    )

if "usesCleartextTraffic" not in manifest:
    manifest = manifest.replace(
        "<application",
        '<application\n        android:usesCleartextTraffic="true"',
        1,
    )

PERMS = """    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
"""
if "READ_MEDIA_VIDEO" not in manifest:
    manifest = manifest.replace("<application", PERMS + "    <application", 1)

manifest = re.sub(r'android:label="[^"]*"', 'android:label="V Player"', manifest, count=1)
MANIFEST.write_text(manifest, encoding="utf-8")
print("Manifest updated")

# ---------- Gradle ----------
kts = ROOT / "build.gradle.kts"
groovy = ROOT / "build.gradle"
gradle_file = kts if kts.exists() else groovy
is_kts = gradle_file == kts
gradle = gradle_file.read_text(encoding="utf-8")

if APP_ID:
    gradle = re.sub(r'applicationId\s*=?\s*"[^"]*"', f'applicationId = "{APP_ID}"', gradle)

if is_kts:
    signing = '''    signingConfigs {
        create("release") {
            keyAlias = System.getenv("KEY_ALIAS")
            keyPassword = System.getenv("KEY_PASSWORD")
            storeFile = file(System.getenv("KEYSTORE_PATH"))
            storePassword = System.getenv("STORE_PASSWORD")
        }
    }

'''
    gradle = gradle.replace("buildTypes {", signing + "    buildTypes {", 1)
    gradle = gradle.replace(
        'signingConfig = signingConfigs.getByName("debug")',
        'signingConfig = signingConfigs.getByName("release")',
    )
else:
    signing = '''    signingConfigs {
        release {
            keyAlias System.getenv("KEY_ALIAS")
            keyPassword System.getenv("KEY_PASSWORD")
            storeFile file(System.getenv("KEYSTORE_PATH"))
            storePassword System.getenv("STORE_PASSWORD")
        }
    }

'''
    gradle = gradle.replace("buildTypes {", signing + "    buildTypes {", 1)
    gradle = gradle.replace(
        "signingConfig signingConfigs.debug",
        "signingConfig signingConfigs.release",
    )

gradle_file.write_text(gradle, encoding="utf-8")
print(f"Gradle updated: {gradle_file}")
